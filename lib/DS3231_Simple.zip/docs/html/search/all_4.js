var searchData=
[
  ['gettemperature',['getTemperature',['../class_d_s3231___simple.html#a1e0be8634d59e9cdd7ad7c112d4a46db',1,'DS3231_Simple']]],
  ['gettemperaturefloat',['getTemperatureFloat',['../class_d_s3231___simple.html#a33e9647bbf146f0a0283e4d9cdc2b140',1,'DS3231_Simple']]]
];
