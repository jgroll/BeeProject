var searchData=
[
  ['begin',['begin',['../class_d_s3231___simple.html#a744a25cfed74ddad9b4c2874d82d836e',1,'DS3231_Simple']]]
];
